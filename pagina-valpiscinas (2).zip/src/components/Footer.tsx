import { Phone, MessageCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-400 py-16 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center text-white font-display font-bold text-lg">
                V
              </div>
              <span className="font-display font-bold text-xl text-white">Valpiscinas.</span>
            </div>
            <p className="text-sm leading-relaxed mb-6">
              Todo lo que tu piscina necesita, con asesoramiento experto de verdad. Más de 30 años de experiencia en Requena y Utiel.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-display font-semibold mb-4">Categorías</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-brand-400 transition-colors">Productos Químicos</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Limpiafondos</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Equipamiento</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Recambios</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-4">Ayuda</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-brand-400 transition-colors">Solucionar problemas</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Envíos y devoluciones</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Preguntas frecuentes</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Contacto</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-4">Contacto</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 mt-0.5 text-brand-400" />
                <span>+34 900 000 000<br/><span className="text-xs text-slate-500">L-V: 9:00 a 14:00 y 16:00 a 19:00</span></span>
              </li>
              <li className="flex items-start gap-2">
                <MessageCircle className="w-4 h-4 mt-0.5 text-brand-400" />
                <span>WhatsApp: +34 600 000 000</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <p>&copy; {new Date().getFullYear()} Valpiscinas. Todos los derechos reservados.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white transition-colors">Aviso Legal</a>
            <a href="#" className="hover:text-white transition-colors">Política de Privacidad</a>
            <a href="#" className="hover:text-white transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
