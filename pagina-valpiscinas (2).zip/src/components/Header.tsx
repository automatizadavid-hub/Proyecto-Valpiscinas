import { ShoppingCart, Menu, Search, MessageCircle } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div className="bg-brand-900 text-white text-xs py-2 px-4 text-center font-medium tracking-wide">
        Expertos en piscinas desde hace +30 años. Envío gratis a partir de 50€.
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center gap-2 cursor-pointer">
            <div className="w-10 h-10 bg-gradient-to-br from-brand-400 to-brand-600 rounded-xl flex items-center justify-center text-white font-display font-bold text-xl shadow-lg shadow-brand-500/30">
              V
            </div>
            <span className="font-display font-bold text-2xl tracking-tight text-slate-900">
              Valpiscinas<span className="text-brand-500">.</span>
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-sm font-medium text-slate-600 hover:text-brand-600 transition-colors">Productos Químicos</a>
            <a href="#" className="text-sm font-medium text-slate-600 hover:text-brand-600 transition-colors">Limpiafondos</a>
            <a href="#" className="text-sm font-medium text-slate-600 hover:text-brand-600 transition-colors">Equipamiento</a>
            <a href="#" className="text-sm font-medium text-slate-600 hover:text-brand-600 transition-colors">Soluciones</a>
            <a href="#" className="text-sm font-medium text-brand-600 hover:text-brand-700 transition-colors flex items-center gap-1">
              <MessageCircle className="w-4 h-4" />
              Asesoramiento
            </a>
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-5">
            <button className="text-slate-400 hover:text-slate-600 transition-colors">
              <Search className="w-5 h-5" />
            </button>
            <button className="text-slate-400 hover:text-slate-600 transition-colors relative">
              <ShoppingCart className="w-5 h-5" />
              <span className="absolute -top-1.5 -right-1.5 bg-brand-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                0
              </span>
            </button>
            <button className="md:hidden text-slate-400 hover:text-slate-600 transition-colors">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
