import { motion } from 'motion/react';
import { 
  Droplet, Bot, Wrench, LifeBuoy, 
  CheckCircle2, Truck, ShieldCheck, Users,
  ArrowRight, Star, MessageCircle,
  PhoneCall, Zap, Activity, ThermometerSun, ShoppingCart
} from 'lucide-react';

export default function Home() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white pt-16 pb-24 lg:pt-24 lg:pb-32">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1576013551627-11971f3f8f36?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center opacity-5"></div>
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-1/3 w-[800px] h-[800px] bg-brand-50 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.div initial={{opacity: 0, y: 20}} animate={{opacity: 1, y: 0}} transition={{duration: 0.5}}>
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-50 text-brand-700 text-sm font-medium mb-6 border border-brand-100">
                <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
                Expertos en piscinas en Requena y Utiel
              </span>
              <h1 className="text-5xl lg:text-7xl font-display font-bold text-slate-900 tracking-tight leading-[1.1] mb-6">
                El agua perfecta <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-cyan-500">no es casualidad.</span>
              </h1>
              <p className="text-lg lg:text-xl text-slate-600 mb-8 leading-relaxed max-w-2xl">
                Es ciencia, experiencia y el producto exacto. Más de 30 años ayudándote a disfrutar de tu piscina sin complicaciones. Todo el equipamiento, química y asesoramiento que necesitas, a un clic.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <button className="inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-xl font-medium hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/20 group">
                  Ver catálogo de productos
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 border border-slate-200 px-8 py-4 rounded-xl font-medium hover:bg-slate-50 hover:border-slate-300 transition-all group">
                  <MessageCircle className="w-5 h-5 text-green-500" />
                  Consultar a un experto
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8 border-t border-slate-100">
                {[
                  { icon: Truck, text: "Envío 24/48h" },
                  { icon: Users, text: "Asesoramiento real" },
                  { icon: ShieldCheck, text: "+30 años exp." },
                  { icon: CheckCircle2, text: "Pago 100% seguro" }
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-slate-600 font-medium">
                    <item.icon className="w-5 h-5 text-brand-500" />
                    {item.text}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Segmentation Section */}
      <section className="py-12 bg-slate-50 relative -mt-8 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Droplet, title: "Producto Químico", desc: "Cloro, algicidas, reguladores", color: "bg-blue-50 text-blue-600" },
              { icon: Bot, title: "Limpiafondos", desc: "Robots automáticos y manuales", color: "bg-cyan-50 text-cyan-600" },
              { icon: Wrench, title: "Equipamiento", desc: "Bombas, filtros, recambios", color: "bg-slate-100 text-slate-600" },
              { icon: LifeBuoy, title: "Resolver Problema", desc: "¿Agua verde? Te ayudamos", color: "bg-emerald-50 text-emerald-600" }
            ].map((item, i) => (
              <a href="#" key={i} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md hover:border-brand-200 transition-all flex flex-col items-start">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${item.color} group-hover:scale-110 transition-transform`}>
                  <item.icon className="w-6 h-6" />
                </div>
                <h3 className="font-display font-semibold text-lg text-slate-900 mb-1">{item.title}</h3>
                <p className="text-sm text-slate-500 mb-4">{item.desc}</p>
                <span className="mt-auto text-sm font-medium text-brand-600 flex items-center gap-1 group-hover:gap-2 transition-all">
                  Explorar <ArrowRight className="w-4 h-4" />
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Why Valpiscinas */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl lg:text-4xl font-display font-bold text-slate-900 mb-4">No somos una tienda más. Somos tu técnico de confianza.</h2>
            <p className="text-lg text-slate-600">Comprar un producto equivocado sale caro. Nuestro diferencial es asegurarnos de que te llevas exactamente lo que tu piscina necesita.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            {[
              { title: "No solo vendemos, resolvemos", desc: "Te guiamos hacia la solución exacta para tu problema de agua, sin hacerte gastar de más en productos innecesarios." },
              { title: "Calidad profesional", desc: "Trabajamos exclusivamente con las marcas y concentraciones que usan los mantenedores profesionales." },
              { title: "Stock real y envío rápido", desc: "Sabemos que un problema en el agua no puede esperar. Si está en la web, está en nuestro almacén listo para salir." },
              { title: "Cercanía y trato humano", desc: "Detrás de esta web hay expertos de Requena dispuestos a coger el teléfono o responderte por WhatsApp." }
            ].map((item, i) => (
              <div key={i} className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center border border-brand-100">
                  <span className="font-display font-bold text-brand-600 text-lg">0{i+1}</span>
                </div>
                <div>
                  <h3 className="text-xl font-display font-semibold text-slate-900 mb-2">{item.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Solutions by Problem */}
      <section className="py-24 bg-slate-900 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brand-600 rounded-full blur-[120px] opacity-20 pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="max-w-2xl">
              <span className="text-brand-400 font-medium tracking-wider uppercase text-sm mb-2 block">Diagnóstico Rápido</span>
              <h2 className="text-3xl lg:text-4xl font-display font-bold mb-4">¿Qué le pasa a tu piscina?</h2>
              <p className="text-slate-400 text-lg">Encuentra la solución directa a los problemas más comunes del agua.</p>
            </div>
            <button className="inline-flex items-center gap-2 text-white bg-white/10 hover:bg-white/20 px-6 py-3 rounded-xl font-medium transition-colors backdrop-blur-sm border border-white/10">
              Ver todas las soluciones
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: "Agua Verde o Turbia", icon: Activity, desc: "Tratamiento de choque y floculación" },
              { title: "Algas en paredes", icon: Zap, desc: "Antialgas concentrado y cepillado" },
              { title: "Olor fuerte a cloro", icon: ThermometerSun, desc: "Ajuste de pH y eliminación de cloraminas" },
              { title: "Pérdida de agua", icon: Droplet, desc: "Diagnóstico de fugas y equipamiento" }
            ].map((item, i) => (
              <a href="#" key={i} className="group bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-all">
                <item.icon className="w-8 h-8 text-brand-400 mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="font-display font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-sm text-slate-400 mb-4">{item.desc}</p>
                <span className="text-brand-400 text-sm font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                  Ver solución <ArrowRight className="w-4 h-4" />
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-display font-bold text-slate-900 mb-4">Los más recomendados</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">Productos de calidad profesional que garantizan resultados. Los mismos que usamos en nuestros mantenimientos.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Cloro Multifunción 5 Acciones 5kg", price: "34,90€", tag: "Más vendido", img: "https://images.unsplash.com/photo-1584483766114-2cea6facdf57?w=500&q=80" },
              { name: "Limpiafondos Dolphin Active X", price: "899,00€", tag: "Premium", img: "https://images.unsplash.com/photo-1576013551627-11971f3f8f36?w=500&q=80" },
              { name: "Clorador Salino 15g/h", price: "450,00€", tag: "Novedad", img: "https://images.unsplash.com/photo-1532614338840-ab30cf10ed36?w=500&q=80" },
              { name: "Bomba de Filtración 1CV", price: "185,00€", tag: "", img: "https://images.unsplash.com/photo-1585122658428-14251786576b?w=500&q=80" }
            ].map((prod, i) => (
              <div key={i} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-xl hover:border-brand-200 transition-all group flex flex-col">
                <div className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 mb-4">
                  {prod.tag && (
                    <span className="absolute top-3 left-3 bg-slate-900 text-white text-xs font-bold px-2 py-1 rounded-md z-10">
                      {prod.tag}
                    </span>
                  )}
                  <img src={prod.img} alt={prod.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                </div>
                <h3 className="font-medium text-slate-900 mb-1 line-clamp-2">{prod.name}</h3>
                <div className="flex items-center gap-1 mb-3">
                  {[1,2,3,4,5].map(star => <Star key={star} className="w-3 h-3 fill-amber-400 text-amber-400" />)}
                  <span className="text-xs text-slate-500 ml-1">(24)</span>
                </div>
                <div className="mt-auto flex items-center justify-between">
                  <span className="font-display font-bold text-lg text-slate-900">{prod.price}</span>
                  <button className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 hover:bg-brand-500 hover:text-white transition-colors">
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WhatsApp Banner */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl shadow-emerald-500/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
            
            <div className="max-w-2xl relative z-10">
              <h2 className="text-3xl font-display font-bold text-white mb-4">¿Dudas con tu piscina? Escríbenos.</h2>
              <p className="text-emerald-50 text-lg mb-6">
                Envíanos una foto de tu piscina o de tu equipo por WhatsApp y te decimos exactamente qué necesitas. Sin bots, atención técnica real de nuestros expertos.
              </p>
              <button className="inline-flex items-center gap-2 bg-white text-emerald-600 px-6 py-3 rounded-xl font-bold hover:bg-emerald-50 transition-colors shadow-lg">
                <MessageCircle className="w-5 h-5" />
                Consultar por WhatsApp
              </button>
            </div>
            
            <div className="relative z-10 flex-shrink-0 hidden md:block">
              <div className="w-32 h-32 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30">
                <PhoneCall className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How We Work */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-display font-bold text-slate-900 mb-4">Cómo trabajamos</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">Un proceso sencillo diseñado para que no pierdas tiempo ni dinero.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 z-0"></div>
            {[
              { step: "1", title: "Diagnóstico", desc: "Identificamos qué necesita tu piscina exactamente." },
              { step: "2", title: "Selección", desc: "Te recomendamos el producto o recambio ideal." },
              { step: "3", title: "Envío", desc: "Lo recibes en casa rápidamente (24/48h)." },
              { step: "4", title: "Disfrute", desc: "Vuelves a tener el agua cristalina y perfecta." }
            ].map((item, i) => (
              <div key={i} className="relative z-10 flex flex-col items-center text-center bg-white p-4">
                <div className="w-16 h-16 rounded-full bg-brand-50 border-4 border-white shadow-md flex items-center justify-center text-brand-600 font-display font-bold text-xl mb-4">
                  {item.step}
                </div>
                <h3 className="font-display font-semibold text-lg text-slate-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-brand-900 text-white text-center">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl lg:text-5xl font-display font-bold mb-6">¿Listo para tener la mejor agua del vecindario?</h2>
          <p className="text-xl text-brand-100 mb-10">Explora nuestra tienda o habla con nosotros si necesitas ayuda para elegir.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="inline-flex items-center justify-center gap-2 bg-brand-500 text-white px-8 py-4 rounded-xl font-medium hover:bg-brand-400 transition-all shadow-lg shadow-brand-500/20">
              Explorar tienda
              <ArrowRight className="w-4 h-4" />
            </button>
            <button className="inline-flex items-center justify-center gap-2 bg-white/10 text-white border border-white/20 px-8 py-4 rounded-xl font-medium hover:bg-white/20 transition-all">
              <MessageCircle className="w-5 h-5" />
              Hablar con un experto
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}
